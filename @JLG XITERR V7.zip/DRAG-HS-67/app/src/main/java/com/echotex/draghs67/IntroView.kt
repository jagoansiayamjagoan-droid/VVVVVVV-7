package com.echotex.draghs67

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import java.util.Random
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * Animasi pembuka bergaya anime: garis kecepatan, sabetan diagonal neon, kilatan putih,
 * layar bergetar, huruf judul "pop" satu per satu, lalu nama developer meluncur masuk.
 * Ketuk layar untuk melewati. Menghapus dirinya sendiri dari layar saat selesai.
 */
class IntroView(ctx: Context) : View(ctx) {

    companion object {
        const val DURATION = 2600L
        private const val TITLE = "DRAG HS 67%"
        private const val DEV = "@JLG×celo"
    }

    private val cyan = ctx.getColor(R.color.neon_cyan)
    private val blue = ctx.getColor(R.color.electric_blue)
    private val rnd = Random(7)
    private val angles = FloatArray(36) { rnd.nextFloat() * 6.2832f }
    private val lens = FloatArray(36) { 0.4f + rnd.nextFloat() * 0.6f }

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        textAlign = Paint.Align.LEFT
    }
    private val slash = Path()

    private var t = 0f
    private var finished = false

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = DURATION
        interpolator = LinearInterpolator()
        addUpdateListener {
            t = it.animatedValue as Float
            alpha = 1f - seg(0.88f, 1f)
            invalidate()
        }
        addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                finish()
            }
        })
    }

    init {
        setBackgroundColor(Color.BLACK)
        isClickable = true
        setOnClickListener { finish() }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        finished = true
        animator.cancel()
        super.onDetachedFromWindow()
    }

    private fun finish() {
        if (finished) return
        finished = true
        animator.cancel()
        (parent as? ViewGroup)?.removeView(this)
    }

    private fun seg(a: Float, b: Float): Float = ((t - a) / (b - a)).coerceIn(0f, 1f)
    private fun lerp(a: Float, b: Float, x: Float): Float = a + (b - a) * x
    private fun easeOutCubic(x: Float): Float {
        val y = 1f - x
        return 1f - y * y * y
    }

    private fun easeOutBack(x: Float): Float {
        val c1 = 1.70158f
        val c3 = c1 + 1f
        val y = x - 1f
        return 1f + c3 * y * y * y + c1 * y * y
    }

    private fun drawSlash(canvas: Canvas, w: Float, h: Float, sp: Float, color: Int, widthFactor: Float) {
        if (sp <= 0f || sp >= 1f) return
        val bw = w * widthFactor
        val skew = h * 0.45f
        val x = lerp(-bw - skew, w + skew, easeOutCubic(sp))
        slash.reset()
        slash.moveTo(x, h)
        slash.lineTo(x + bw, h)
        slash.lineTo(x + bw + skew, 0f)
        slash.lineTo(x + skew, 0f)
        slash.close()
        fillPaint.color = color
        fillPaint.alpha = (210 * (1f - sp * 0.6f)).toInt()
        canvas.drawPath(slash, fillPaint)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w == 0f || h == 0f) return
        val cx = w / 2f
        val cy = h / 2f
        val diag = hypot(w, h)
        val d1 = context.dp(1).toFloat().coerceAtLeast(1f)

        canvas.save()

        // Layar bergetar saat sabetan kena
        val sh = seg(0.2f, 0.4f)
        if (sh > 0.001f && sh < 0.999f) {
            val amp = context.dp(8) * (1f - sh)
            canvas.translate((rnd.nextFloat() - 0.5f) * amp * 2f, (rnd.nextFloat() - 0.5f) * amp * 2f)
        }

        // Garis kecepatan
        val p = easeOutCubic(seg(0f, 0.22f))
        val out = 1f - seg(0.42f, 0.58f)
        if (out > 0f) {
            for (i in angles.indices) {
                val r1 = diag * lerp(0.75f, 0.12f, p)
                val r2 = r1 + diag * 0.28f * lens[i]
                linePaint.color = if (i % 2 == 0) cyan else blue
                linePaint.alpha = (230 * out).toInt()
                linePaint.strokeWidth = context.dp(2) + lens[i] * context.dp(3)
                canvas.drawLine(
                    cx + cos(angles[i]) * r1, cy + sin(angles[i]) * r1,
                    cx + cos(angles[i]) * r2, cy + sin(angles[i]) * r2,
                    linePaint
                )
            }
        }

        // Sabetan diagonal neon (dua lapis)
        drawSlash(canvas, w, h, seg(0.16f, 0.44f), blue, 0.18f)
        drawSlash(canvas, w, h, seg(0.12f, 0.40f), cyan, 0.30f)

        // Garis bingkai + teks sistem
        val fr = easeOutCubic(seg(0.02f, 0.2f))
        val barH = h * 0.12f
        linePaint.color = cyan
        linePaint.alpha = (160 * fr).toInt()
        linePaint.strokeWidth = d1
        canvas.drawLine(cx - cx * fr, barH, cx + cx * fr, barH, linePaint)
        canvas.drawLine(cx - cx * fr, h - barH, cx + cx * fr, h - barH, linePaint)
        textPaint.clearShadowLayer()
        textPaint.textSize = w * 0.032f
        textPaint.letterSpacing = 0.12f
        textPaint.color = cyan
        textPaint.alpha = (150 * seg(0.1f, 0.3f)).toInt()
        canvas.drawText("INITIALIZING DRAG SYSTEM...", context.dp(14).toFloat(), barH - context.dp(8), textPaint)

        // Judul: huruf "pop" satu per satu dengan cahaya neon
        textPaint.letterSpacing = 0f
        textPaint.textSize = w * 0.1f
        textPaint.setShadowLayer(context.dp(14).toFloat(), 0f, 0f, cyan)
        val widths = FloatArray(TITLE.length) { textPaint.measureText(TITLE[it].toString()) }
        val total = widths.sum()
        val base = cy + textPaint.textSize * 0.35f
        var x = cx - total / 2f
        for (i in TITLE.indices) {
            val s0 = 0.30f + i * 0.022f
            val a = seg(s0, s0 + 0.12f)
            if (a > 0f) {
                val sc = easeOutBack(a)
                textPaint.color = if (i >= 8) cyan else Color.WHITE
                textPaint.alpha = (255 * a).toInt()
                canvas.save()
                canvas.translate(x + widths[i] / 2f, base - (1f - a) * h * 0.08f)
                canvas.scale(sc, sc)
                canvas.drawText(TITLE[i].toString(), -widths[i] / 2f, 0f, textPaint)
                canvas.restore()
            }
            x += widths[i]
        }

        // Garis bawah yang melebar dari tengah
        val ul = easeOutCubic(seg(0.62f, 0.8f))
        if (ul > 0f) {
            linePaint.color = cyan
            linePaint.alpha = 255
            linePaint.strokeWidth = context.dp(3).toFloat()
            val ly = base + textPaint.textSize * 0.25f
            canvas.drawLine(cx - total / 2f * ul, ly, cx + total / 2f * ul, ly, linePaint)
        }

        // Katakana kecil di atas judul
        val ka = seg(0.5f, 0.65f)
        if (ka > 0f) {
            textPaint.textSize = w * 0.045f
            textPaint.letterSpacing = 0.4f
            textPaint.color = cyan
            textPaint.alpha = (255 * ka).toInt()
            val kw = textPaint.measureText("ドラッグ")
            canvas.drawText("ドラッグ", cx - kw / 2f, base - w * 0.1f * 1.15f, textPaint)
        }

        // Nama developer meluncur dari kanan
        val dv = seg(0.68f, 0.85f)
        if (dv > 0f) {
            textPaint.letterSpacing = 0.1f
            textPaint.textSize = w * 0.05f
            textPaint.color = Color.WHITE
            textPaint.alpha = (255 * seg(0.68f, 0.8f)).toInt()
            val dw = textPaint.measureText(DEV)
            val slideX = (1f - easeOutCubic(dv)) * w * 0.4f
            canvas.drawText(DEV, cx - dw / 2f + slideX, base + w * 0.1f * 1.0f, textPaint)
        }

        canvas.restore()

        // Kilatan putih
        val fl = if (t >= 0.22f) 1f - seg(0.22f, 0.36f) else 0f
        if (fl > 0f) {
            fillPaint.color = Color.WHITE
            fillPaint.alpha = (200 * fl).toInt()
            canvas.drawRect(0f, 0f, w, h, fillPaint)
        }
    }
}
